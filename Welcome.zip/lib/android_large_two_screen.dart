import 'package:flutter/material.dart';

class AndroidLargeTwoScreen extends StatelessWidget {
  const AndroidLargeTwoScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        body: SizedBox(
          width: 360,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 102,
                width: 264,
                margin: EdgeInsets.only(right: 4),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Text(
                      "WELCOME",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Color(0XFFFF4D4D),
                        fontSize: 39.40707015991211,
                        fontFamily: 'Inknut Antiqua',
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Container(
                      height: 102,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Text(
                            "WELCOME",
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Color(0XFFFF4D4D),
                              fontSize: 39.40707015991211,
                              fontFamily: 'Inknut Antiqua',
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Container(
                            height: 102,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Text(
                                  "WELCOME",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Color(0XFFFF4D4D),
                                    fontSize: 39.40707015991211,
                                    fontFamily: 'Inknut Antiqua',
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                Container(
                                  height: 102,
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Text(
                                        "WELCOME",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Color(0XFFFF4D4D),
                                          fontSize: 39.40707015991211,
                                          fontFamily: 'Inknut Antiqua',
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ),
                                      Text(
                                        "WELCOME",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Color(0XFFFF4D4D),
                                          fontSize: 39.40707015991211,
                                          fontFamily: 'Inknut Antiqua',
                                          fontWeight: FontWeight.w800,
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(height: 4)
            ],
          ),
        ),
      ),
    );
  }
}
