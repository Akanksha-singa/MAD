package com.createaccount.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
