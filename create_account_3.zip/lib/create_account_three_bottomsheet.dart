import 'package:flutter/material.dart';
import 'package:country_pickers/country.dart';
import 'package:country_pickers/country_pickers.dart';
import 'widgets.dart'; // ignore_for_file: must_be_immutable
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class CreateAccountThreeBottomsheet extends StatelessWidget {
  CreateAccountThreeBottomsheet({Key? key})
      : super(
          key: key,
        );

  Country selectedCountry = CountryPickerUtils.getCountryByPhoneCode('962');

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0XFF000000),
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(16),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildForgotPasswordRow(context),
          SizedBox(height: 24),
          _buildInputSection(context),
          SizedBox(height: 48),
          SizedBox(
            width: double.maxFinite,
            height: 44,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0XFFFF4D4D),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                ),
                visualDensity: const VisualDensity(
                  vertical: -4,
                  horizontal: -4,
                ),
                padding: EdgeInsets.symmetric(
                  horizontal: 30,
                  vertical: 12,
                ),
              ),
              onPressed: () {},
              child: Text(
                "Send reset link",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          SizedBox(height: 24),
          Text(
            "Use email instead",
            style: TextStyle(
              color: Color(0XFFFF4D4D),
              fontSize: 14,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 24)
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildForgotPasswordRow(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        mainAxisSize: MainAxisSize.max,
        children: [
          Text(
            "Forgot your password?",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 16,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            "Done",
            style: TextStyle(
              color: Color(0XFFFF4D4D),
              fontSize: 14,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w600,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildInputSection(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Mobile number",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 4),
          SizedBox(
            width: double.maxFinite,
            child: CustomPhoneNumber(
              country: selectedCountry,
              onTap: (Country value) {
                selectedCountry = value;
              },
            ),
          )
        ],
      ),
    );
  }
}
