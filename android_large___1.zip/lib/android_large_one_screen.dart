import 'package:flutter/material.dart';

class AndroidLargeOneScreen extends StatelessWidget {
  const AndroidLargeOneScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 100,
          ),
          child: Column(
            children: [_buildInformationColumn(context), SizedBox(height: 4)],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 68,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 40,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 24,
          top: 18,
          bottom: 21,
        ),
        child: SizedBox(
          height: 16,
          width: 16,
          child: SvgPicture.asset(
            "assets/images/img_icon_arrow_down.svg",
          ),
        ),
      ),
      title: Padding(
        padding: EdgeInsets.only(left: 16),
        child: Text(
          "App information",
          style: TextStyle(
            color: Color(0XFFFFFFFF),
            fontSize: 20,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildInformationList(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: ListView.separated(
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (context, index) {
          return SizedBox(
            height: 18,
          );
        },
        itemCount: 3,
        itemBuilder: (context, index) {
          return InformationlistItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildInformationColumn(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        children: [_buildInformationList(context)],
      ),
    );
  }
}

// ignore: must_be_immutable
class InformationlistItemWidget extends StatelessWidget {
  const InformationlistItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return _buildManufactureDateSection(context);
  }

  /// Section Widget
  Widget _buildManufactureDateSection(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: double.maxFinite,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              Text(
                "Date of manufacture",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 16,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                "     June 2024",
                style: TextStyle(
                  color: Color(0XFFFF4D4D),
                  fontSize: 16,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              )
            ],
          ),
        ),
        SizedBox(height: 10),
        SizedBox(
          width: double.maxFinite,
          child: Divider(
            height: 1,
            thickness: 1,
            color: Color(0XFFFFFFFF),
          ),
        )
      ],
    );
  }
}
