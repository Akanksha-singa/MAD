import 'package:flutter/material.dart';
import '../your_expenses_screen.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class AppRoutes {
  static const String yourExpensesScreen = '/your_expenses_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> routes = {
    yourExpensesScreen: (context) => YourExpensesScreen(),
    initialRoute: (context) => YourExpensesScreen()
  };
}
