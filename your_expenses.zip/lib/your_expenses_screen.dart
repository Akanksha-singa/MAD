import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class YourExpensesScreen extends StatelessWidget {
  const YourExpensesScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        appBar: _buildAppBar(context),
        body: Padding(
          padding: EdgeInsets.only(
            left: 42,
            right: 46,
            bottom: 470,
          ),
          child: SizedBox(
            height: 264,
            child: SvgPicture.asset(
              "assets/images/img_objects.svg",
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 64,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 66,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 8,
          top: 21,
          bottom: 22,
        ),
        child: Row(
          children: [
            SizedBox(
              height: 20,
              width: 20,
              child: SvgPicture.asset(
                "assets/images/img_arrow_left.svg",
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 2,
                bottom: 1,
              ),
              child: Text(
                "Back",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          ],
        ),
      ),
      centerTitle: true,
      title: Text(
        "Your Expenses",
        style: TextStyle(
          color: Color(0XFFFFFFFF),
          fontSize: 13,
          fontFamily: 'Inter',
          fontWeight: FontWeight.w700,
        ),
      ),
      actions: [
        Padding(
          padding: EdgeInsets.only(
            top: 20,
            right: 23,
            bottom: 20,
          ),
          child: SizedBox(
            height: 24,
            width: 24,
            child: SvgPicture.asset(
              "assets/images/img_vector.svg",
            ),
          ),
        )
      ],
      flexibleSpace: Container(
        height: 64,
        width: 360,
        decoration: BoxDecoration(
          color: Color(0XFFFF4D4D),
        ),
      ),
    );
  }
}
