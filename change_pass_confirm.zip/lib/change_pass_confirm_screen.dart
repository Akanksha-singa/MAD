import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class ChangePassConfirmScreen extends StatelessWidget {
  const ChangePassConfirmScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 30,
          ),
          child: Column(
            children: [
              Padding(
                child: SizedBox(
                  height: 216,
                  width: double.maxFinite,
                  child: SvgPicture.asset(
                    "assets/images/img_illustration_1.svg",
                  ),
                ),
              ),
              SizedBox(height: 56),
              Text(
                "Change password successfully!",
                style: TextStyle(
                  color: Color(0XFFFF4D4D),
                  fontSize: 16,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 22),
              Text(
                "You have successfully change password.\nPlease use the new password when Sign in.",
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 30),
              SizedBox(
                width: double.maxFinite,
                height: 44,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0XFFFF4D4D),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        14,
                      ),
                    ),
                    visualDensity: const VisualDensity(
                      vertical: -4,
                      horizontal: -4,
                    ),
                    padding: EdgeInsets.symmetric(
                      horizontal: 30,
                      vertical: 10,
                    ),
                  ),
                  onPressed: () {},
                  child: Text(
                    "Ok",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 4)
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 66,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 32,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 24,
          top: 20,
          bottom: 22,
        ),
        child: SizedBox(
          height: 14,
          child: SvgPicture.asset(
            "assets/images/img_path.svg",
          ),
        ),
      ),
    );
  }
}
