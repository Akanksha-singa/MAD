import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class CreateAccountFourScreen extends StatelessWidget {
  CreateAccountFourScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController nameController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  bool termsAndConditions = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Spacer(),
              Text(
                "Create Account",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 21,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 26),
              _buildNameInput(context),
              SizedBox(height: 16),
              _buildEmailInput(context),
              SizedBox(height: 16),
              _buildPasswordInput(context),
              SizedBox(height: 24),
              _buildTermsAndConditions(context),
              SizedBox(height: 48),
              SizedBox(
                width: double.maxFinite,
                height: 44,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0XFFFF4D4D),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        4,
                      ),
                    ),
                    visualDensity: const VisualDensity(
                      vertical: -4,
                      horizontal: -4,
                    ),
                    padding: EdgeInsets.symmetric(
                      horizontal: 30,
                      vertical: 12,
                    ),
                  ),
                  onPressed: () {},
                  child: Text(
                    "Create a new account",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 14,
                      fontFamily: 'Sora',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 16),
              _buildDividerSection(context)
            ],
          ),
        ),
        bottomNavigationBar: _buildSocialLogin(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 56,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 66,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 8,
          top: 18,
          bottom: 18,
        ),
        child: Row(
          children: [
            SizedBox(
              height: 20,
              width: 20,
              child: SvgPicture.asset(
                "assets/images/img_arrow_left.svg",
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 2,
                bottom: 1,
              ),
              child: Text(
                "Back",
                style: TextStyle(
                  color: Color(0XFFFF4D4D),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildNameInput(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Name",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 4),
          Container(
            width: 328,
            child: TextFormField(
              focusNode: FocusNode(),
              autofocus: true,
              controller: nameController,
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 14,
                fontFamily: 'Sora',
                fontWeight: FontWeight.w400,
              ),
              decoration: InputDecoration(
                hintText: "e.g. John Doe",
                hintStyle: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w400,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                disabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                isDense: true,
                contentPadding: EdgeInsets.all(12),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildEmailInput(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Email",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 4),
          Container(
            width: 328,
            child: TextFormField(
              focusNode: FocusNode(),
              autofocus: true,
              controller: emailController,
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 14,
                fontFamily: 'Sora',
                fontWeight: FontWeight.w400,
              ),
              decoration: InputDecoration(
                hintText: "e.g. email@example.com",
                hintStyle: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w400,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                disabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                isDense: true,
                contentPadding: EdgeInsets.all(12),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildPasswordInput(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Password",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 4),
          Container(
            width: 328,
            child: TextFormField(
              focusNode: FocusNode(),
              autofocus: true,
              controller: passwordController,
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 14,
                fontFamily: 'Sora',
                fontWeight: FontWeight.w400,
              ),
              textInputAction: TextInputAction.done,
              obscureText: true,
              decoration: InputDecoration(
                hintText: "Enter your password",
                hintStyle: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w400,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                disabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                suffixIcon: Container(
                  margin: EdgeInsets.fromLTRB(30, 12, 12, 12),
                  child: SvgPicture.asset(
                    "assets/images/img_eyeoffline.svg",
                    height: 20,
                    width: 20,
                  ),
                ),
                suffixIconConstraints: BoxConstraints(
                  maxHeight: 44,
                ),
                isDense: true,
                contentPadding: EdgeInsets.only(
                  left: 12,
                  top: 12,
                  bottom: 12,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildTermsAndConditions(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        children: [
          SizedBox(
            child: Checkbox(
              shape: RoundedRectangleBorder(),
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              value: termsAndConditions,
              onChanged: (value) {
                termsAndConditions = value ?? false;
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 10,
            ),
            child: Text(
              "I accept terms and conditions and privacy policy",
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 12,
                fontFamily: 'Sora',
                fontWeight: FontWeight.w400,
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildDividerSection(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            child: Divider(
              height: 1,
              thickness: 1,
              color: Color(0XFFFFFFFF),
            ),
          ),
          SizedBox(width: 16),
          Text(
            "or continue using",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Divider(
              height: 1,
              thickness: 1,
              color: Color(0XFFFFFFFF),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSocialLogin(BuildContext context) {
    return Container(
      height: 44,
      margin: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: 30,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Spacer(
            flex: 41,
          ),
          Container(
            height: 24,
            width: 24,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(
                4,
              ),
              border: Border.all(
                color: Color(0XFFEDEEF6),
                width: 1,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                IconButton(
                  onPressed: () {},
                  constraints: BoxConstraints(
                    minHeight: 24,
                    minWidth: 24,
                  ),
                  padding: EdgeInsets.all(0),
                  icon: Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: Color(0XFF1977F3),
                      borderRadius: BorderRadius.circular(
                        12,
                      ),
                    ),
                    child: SvgPicture.asset(
                      "assets/images/img_facebook_f_logo_2019.svg",
                    ),
                  ),
                )
              ],
            ),
          ),
          Spacer(
            flex: 58,
          ),
          Container(
            height: 44,
            width: 98,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(
                4,
              ),
              border: Border.all(
                color: Color(0XFFEDEEF6),
                width: 1,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Padding(
                  child: SizedBox(
                    height: 24,
                    width: 22,
                    child: SvgPicture.asset(
                      "assets/images/img_google.svg",
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            height: 44,
            width: 98,
            margin: EdgeInsets.only(left: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(
                4,
              ),
              border: Border.all(
                color: Color(0XFFEDEEF6),
                width: 1,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Padding(
                  child: SizedBox(
                    height: 24,
                    width: 18,
                    child: SvgPicture.asset(
                      "assets/images/img_path1504.svg",
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
