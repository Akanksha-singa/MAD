package com.forpass.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
