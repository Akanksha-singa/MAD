import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class PaymentFailScreen extends StatelessWidget {
  const PaymentFailScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 66,
            top: 192,
            bottom: 192,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.center,
                child: Container(
                  height: 126,
                  width: 196,
                  margin: EdgeInsets.symmetric(horizontal: 14),
                  child: Stack(
                    alignment: Alignment.centerLeft,
                    children: [
                      Container(
                        width: 126,
                        margin: EdgeInsets.only(left: 18),
                        padding: EdgeInsets.symmetric(horizontal: 26),
                        decoration: BoxDecoration(
                          color: Color(0XFFE05555),
                          borderRadius: BorderRadius.circular(
                            62,
                          ),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(height: 40),
                            Container(
                              width: double.maxFinite,
                              padding: EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 10,
                              ),
                              decoration: BoxDecoration(
                                color: Color(0XFFFFFFFF),
                                borderRadius: BorderRadius.circular(
                                  8,
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Padding(
                                    child: SizedBox(
                                      height: 40,
                                      width: double.maxFinite,
                                      child: SvgPicture.asset(
                                        "assets/images/img_close_line.svg",
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Padding(
                                    child: SizedBox(
                                      height: 18,
                                      width: double.maxFinite,
                                      child: SvgPicture.asset(
                                        "assets/images/img_lines.svg",
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                      Align(
                        alignment: Alignment.topCenter,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 154,
                              margin: EdgeInsets.only(left: 4),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    height: 16,
                                    width: 16,
                                    decoration: BoxDecoration(
                                      color: Color(0XFFFFD5D5),
                                      borderRadius: BorderRadius.circular(
                                        8,
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Container(
                                      height: 8,
                                      width: 8,
                                      decoration: BoxDecoration(
                                        color: Color(0XFFFFD5D5),
                                        borderRadius: BorderRadius.circular(
                                          4,
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(height: 74),
                            SizedBox(
                              width: 162,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    height: 8,
                                    width: 8,
                                    margin: EdgeInsets.only(top: 2),
                                    decoration: BoxDecoration(
                                      color: Color(0XFFFFD5D5),
                                      borderRadius: BorderRadius.circular(
                                        4,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    height: 16,
                                    width: 16,
                                    decoration: BoxDecoration(
                                      color: Color(0XFFFFD5D5),
                                      borderRadius: BorderRadius.circular(
                                        8,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),
              Padding(
                padding: EdgeInsets.only(left: 28),
                child: Text(
                  "Transfer Failed :(",
                  style: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 16,
                    fontFamily: 'Sora',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              SizedBox(height: 8),
              SizedBox(
                width: 190,
                child: Text(
                  "Your transfer has been declined due to a technical issue",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 12,
                    fontFamily: 'Sora',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
              SizedBox(height: 4)
            ],
          ),
        ),
        bottomNavigationBar: _buildBackToWalletButton(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildBackToWalletButton(BuildContext context) {
    return Container(
      width: double.maxFinite,
      height: 44,
      margin: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: 42,
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Color(0XFFFF4D4D),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
              4,
            ),
          ),
          visualDensity: const VisualDensity(
            vertical: -4,
            horizontal: -4,
          ),
          padding: EdgeInsets.symmetric(
            horizontal: 30,
            vertical: 12,
          ),
        ),
        onPressed: () {},
        child: Text(
          "Back to wallet",
          style: TextStyle(
            color: Color(0XFFFFFFFF),
            fontSize: 14,
            fontFamily: 'Sora',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
