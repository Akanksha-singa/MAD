import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class PaymentSuccessScreen extends StatelessWidget {
  const PaymentSuccessScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 56,
          ),
          child: Column(
            children: [
              Padding(
                child: SizedBox(
                  height: 188,
                  width: double.maxFinite,
                  child: SvgPicture.asset(
                    "assets/images/img_illustration_4.svg",
                  ),
                ),
              ),
              SizedBox(height: 24),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 74),
                  child: Text(
                    "Transfer successful!",
                    style: TextStyle(
                      color: Color(0XFFFF4D4D),
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 24),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "You have successfully transferred \n",
                      style: TextStyle(
                        color: Color(0XFFFFFFFF),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    TextSpan(
                      text: "\$ 1,",
                      style: TextStyle(
                        color: Color(0XFFFF4267),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    TextSpan(
                      text: "000",
                      style: TextStyle(
                        color: Color(0XFFFF4D4D),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    TextSpan(
                      text: " to ",
                      style: TextStyle(
                        color: Color(0XFFFFFFFF),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    TextSpan(
                      text: "Ajay N M!",
                      style: TextStyle(
                        color: Color(0XFFE77676),
                        fontSize: 14,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w700,
                      ),
                    )
                  ],
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 4)
            ],
          ),
        ),
        bottomNavigationBar: _buildBackToWalletButton(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 56,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 40,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 24,
          top: 20,
          bottom: 19,
        ),
        child: SizedBox(
          height: 16,
          width: 16,
          child: SvgPicture.asset(
            "assets/images/img_icon_arrow_down.svg",
          ),
        ),
      ),
      title: Padding(
        padding: EdgeInsets.only(left: 8),
        child: Text(
          "Confirm",
          style: TextStyle(
            color: Color(0XFF333333),
            fontSize: 20,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBackToWalletButton(BuildContext context) {
    return Container(
      width: double.maxFinite,
      height: 44,
      margin: EdgeInsets.only(
        left: 14,
        right: 18,
        bottom: 32,
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Color(0XFFFF4D4D),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
              14,
            ),
          ),
          visualDensity: const VisualDensity(
            vertical: -4,
            horizontal: -4,
          ),
          padding: EdgeInsets.symmetric(
            horizontal: 30,
            vertical: 10,
          ),
        ),
        onPressed: () {},
        child: Text(
          "Back to wallet",
          style: TextStyle(
            color: Color(0XFFFFFFFF),
            fontSize: 16,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
