import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class ChangePassScreen extends StatelessWidget {
  ChangePassScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController newpasswordController = TextEditingController();

  TextEditingController confirmpasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 32,
            vertical: 50,
          ),
          child: Column(
            children: [
              _buildNewPasswordSection(context),
              SizedBox(height: 18),
              _buildConfirmPasswordSection(context),
              SizedBox(height: 64),
              SizedBox(
                width: double.maxFinite,
                height: 44,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0XFFFF4D4D),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        14,
                      ),
                    ),
                    visualDensity: const VisualDensity(
                      vertical: -4,
                      horizontal: -4,
                    ),
                    padding: EdgeInsets.symmetric(
                      horizontal: 30,
                      vertical: 10,
                    ),
                  ),
                  onPressed: () {},
                  child: Text(
                    "Change password",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 16,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 4)
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 68,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 40,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 24,
          top: 17,
          bottom: 22,
        ),
        child: SizedBox(
          height: 16,
          width: 16,
          child: SvgPicture.asset(
            "assets/images/img_icon_arrow_down.svg",
          ),
        ),
      ),
      title: Padding(
        padding: EdgeInsets.only(left: 16),
        child: Text(
          "Change password",
          style: TextStyle(
            color: Color(0XFFFFFFFF),
            fontSize: 20,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildNewPasswordSection(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Type your new password",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 4),
          Container(
            width: 296,
            child: TextFormField(
              focusNode: FocusNode(),
              autofocus: true,
              controller: newpasswordController,
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 14,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
              ),
              obscureText: true,
              decoration: InputDecoration(
                hintText: "************",
                hintStyle: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    14,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    14,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                disabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    14,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    14,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                suffixIcon: Container(
                  margin: EdgeInsets.fromLTRB(30, 14, 12, 14),
                  child: SvgPicture.asset(
                    "assets/images/img_icon_07.svg",
                    height: 16,
                    width: 16,
                  ),
                ),
                suffixIconConstraints: BoxConstraints(
                  maxHeight: 44,
                ),
                isDense: true,
                contentPadding: EdgeInsets.only(
                  left: 10,
                  top: 10,
                  bottom: 10,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildConfirmPasswordSection(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Confirm password",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 6),
          Container(
            width: 296,
            child: TextFormField(
              focusNode: FocusNode(),
              autofocus: true,
              controller: confirmpasswordController,
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 14,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
              ),
              textInputAction: TextInputAction.done,
              obscureText: true,
              decoration: InputDecoration(
                hintText: "************ |",
                hintStyle: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 14,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    14,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    14,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                disabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    14,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    14,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                suffixIcon: Container(
                  margin: EdgeInsets.fromLTRB(30, 14, 14, 14),
                  child: SvgPicture.asset(
                    "assets/images/img_icon_07.svg",
                    height: 16,
                    width: 16,
                  ),
                ),
                suffixIconConstraints: BoxConstraints(
                  maxHeight: 44,
                ),
                isDense: true,
                contentPadding: EdgeInsets.only(
                  left: 10,
                  top: 10,
                  bottom: 10,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
