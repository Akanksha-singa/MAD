import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class ProfileSettingsScreen extends StatelessWidget {
  const ProfileSettingsScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFFFF4D4D),
        body: SizedBox(
          height: 800,
          width: 360,
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 46,
                ),
                decoration: BoxDecoration(
                  color: Color(0XFF000000),
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(60),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "Rex Kyojuro",
                      style: TextStyle(
                        color: Color(0XFFFFFFFF),
                        fontSize: 20.80000114440918,
                        fontFamily: 'Lato',
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(height: 60),
                    _buildUserProfileList(context),
                    SizedBox(height: 12),
                    _buildChangePasswordRow(context),
                    SizedBox(height: 240)
                  ],
                ),
              ),
              _buildProfileSettingsColumn(context)
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileList(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (context, index) {
          return SizedBox(
            height: 12,
          );
        },
        itemCount: 3,
        itemBuilder: (context, index) {
          return UserprofilelistItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildChangePasswordRow(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.max,
        children: [
          IconButton(
            onPressed: () {},
            constraints: BoxConstraints(
              minHeight: 32,
              minWidth: 32,
            ),
            padding: EdgeInsets.all(0),
            icon: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: Color(0XFFFF4D4D),
                borderRadius: BorderRadius.circular(
                  8,
                ),
              ),
              padding: EdgeInsets.all(6),
              child: SvgPicture.asset(
                "assets/images/img_lock_2_line.svg",
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 8),
            child: Text(
              "Change password",
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 12,
                fontFamily: 'Sora',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Spacer(),
          Padding(
            child: SizedBox(
              height: 16,
              width: 16,
              child: SvgPicture.asset(
                "assets/images/img_arrow_right.svg",
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildProfileSettingsColumn(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Padding(
        padding: EdgeInsets.only(
          left: 24,
          top: 24,
          right: 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppBar(
              elevation: 0,
              toolbarHeight: 30,
              backgroundColor: Colors.transparent,
              automaticallyImplyLeading: false,
              leadingWidth: 40,
              leading: Padding(
                padding: EdgeInsets.only(
                  left: 24,
                  top: 5,
                  bottom: 8,
                ),
                child: SizedBox(
                  height: 16,
                  width: 16,
                  child: SvgPicture.asset(
                    "assets/images/img_icon_arrow_down.svg",
                  ),
                ),
              ),
              title: Padding(
                padding: EdgeInsets.only(left: 8),
                child: Text(
                  "Profile Settings",
                  style: TextStyle(
                    color: Color(0XFF000000),
                    fontSize: 20,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            SizedBox(height: 60),
            Container(
              height: 80,
              width: 80,
              decoration: BoxDecoration(
                color: Color(0XFFFFFFFF),
                borderRadius: BorderRadius.circular(
                  40,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "R",
                    style: TextStyle(
                      color: Color(0XFF4CBB9B),
                      fontSize: 46.80000305175781,
                      fontFamily: 'Roboto',
                      fontWeight: FontWeight.w400,
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class UserprofilelistItemWidget extends StatelessWidget {
  const UserprofilelistItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(
                    left: 40,
                    bottom: 18,
                  ),
                  child: Text(
                    "Full name",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 12,
                      fontFamily: 'Sora',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                Text(
                  "Edit",
                  style: TextStyle(
                    color: Color(0XFFE77676),
                    fontSize: 12,
                    fontFamily: 'Sora',
                    fontWeight: FontWeight.w400,
                  ),
                )
              ],
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: double.maxFinite,
                margin: EdgeInsets.symmetric(horizontal: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(bottom: 6),
                      child: SizedBox(
                        height: 20,
                        width: 20,
                        child: SvgPicture.asset(
                          "assets/images/img_user_6_line.svg",
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 14),
                      child: Text(
                        "Rex Kyojuro ",
                        style: TextStyle(
                          color: Color(0XFFFFFFFF),
                          fontSize: 12,
                          fontFamily: 'Sora',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(height: 12),
              SizedBox(
                width: double.maxFinite,
                child: Divider(
                  height: 1,
                  thickness: 1,
                  color: Color(0XFFFFFFFF),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
