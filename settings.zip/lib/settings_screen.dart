import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFFFF4D4D),
        body: SizedBox(
          height: 800,
          width: 360,
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 46,
                ),
                decoration: BoxDecoration(
                  color: Color(0XFF000000),
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(60),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildMainContentSection(context),
                    SizedBox(height: 240)
                  ],
                ),
              ),
              _buildNavigationSection(context)
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildCustomerCareSection(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        children: [
          SizedBox(
            width: double.maxFinite,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  "Customer care",
                  style: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 16,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  "19008989",
                  style: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 12,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                  ),
                )
              ],
            ),
          ),
          SizedBox(height: 10),
          SizedBox(
            width: double.maxFinite,
            child: Divider(
              height: 1,
              thickness: 1,
              color: Color(0XFFFFFFFF),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildMainContentSection(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.only(left: 16),
      child: Column(
        children: [
          Text(
            "Rex Kyojuro",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 20.80000114440918,
              fontFamily: 'Lato',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 42),
          SizedBox(
            width: double.maxFinite,
            child: _buildAppInformationSection(context),
          ),
          SizedBox(height: 12),
          SizedBox(
            width: double.maxFinite,
            child: _buildAppInformationSection(context),
          ),
          SizedBox(height: 14),
          _buildCustomerCareSection(context),
          SizedBox(height: 12),
          SizedBox(
            width: double.maxFinite,
            child: _buildLogoutSection(context),
          ),
          SizedBox(height: 12),
          SizedBox(
            width: double.maxFinite,
            child: _buildLogoutSection(context),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNavigationSection(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Padding(
        padding: EdgeInsets.only(
          left: 24,
          top: 24,
          right: 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppBar(
              elevation: 0,
              toolbarHeight: 30,
              backgroundColor: Colors.transparent,
              automaticallyImplyLeading: false,
              leadingWidth: 40,
              leading: Padding(
                padding: EdgeInsets.only(
                  left: 24,
                  top: 5,
                  bottom: 8,
                ),
                child: SizedBox(
                  height: 16,
                  width: 16,
                  child: SvgPicture.asset(
                    "assets/images/img_icon_arrow_down.svg",
                  ),
                ),
              ),
              title: Padding(
                padding: EdgeInsets.only(left: 8),
                child: Text(
                  "Settings",
                  style: TextStyle(
                    color: Color(0XFF000000),
                    fontSize: 20,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            SizedBox(height: 60),
            Container(
              height: 80,
              width: 80,
              decoration: BoxDecoration(
                color: Color(0XFFFFFFFF),
                borderRadius: BorderRadius.circular(
                  40,
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "R",
                    style: TextStyle(
                      color: Color(0XFF4CBB9B),
                      fontSize: 46.80000305175781,
                      fontFamily: 'Roboto',
                      fontWeight: FontWeight.w400,
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildAppInformationSection(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: double.maxFinite,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: [
              Text(
                "App information",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 16,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                ),
              ),
              Padding(
                child: SizedBox(
                  height: 16,
                  width: 16,
                  child: SvgPicture.asset(
                    "assets/images/img_arrow_right.svg",
                  ),
                ),
              )
            ],
          ),
        ),
        SizedBox(height: 10),
        SizedBox(
          width: double.maxFinite,
          child: Divider(
            height: 1,
            thickness: 1,
            color: Color(0XFFFFFFFF),
          ),
        )
      ],
    );
  }

  /// Common widget
  Widget _buildLogoutSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "LOG OUT",
          style: TextStyle(
            color: Color(0XFFFFFFFF),
            fontSize: 16,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
          ),
        ),
        SizedBox(height: 10),
        SizedBox(
          width: double.maxFinite,
          child: Divider(
            height: 1,
            thickness: 1,
            color: Color(0XFFFFFFFF),
          ),
        )
      ],
    );
  }
}
