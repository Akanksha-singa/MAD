import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class TransferToOneScreen extends StatelessWidget {
  TransferToOneScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController priceController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Column(
          children: [
            Text(
              "Transfer to",
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 24,
                fontFamily: 'Sora',
                fontWeight: FontWeight.w400,
              ),
            ),
            SizedBox(height: 26),
            Container(
              width: double.maxFinite,
              margin: EdgeInsets.symmetric(horizontal: 82),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(
                      36,
                    ),
                    child: Image.asset(
                      "assets/images/img_profile_photo.png",
                      height: 72,
                      width: 72,
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Ajay N M",
                          style: TextStyle(
                            color: Color(0XFFFFFFFF),
                            fontSize: 16,
                            fontFamily: 'Sora',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          "+91 7892817647",
                          style: TextStyle(
                            color: Color(0XFF78838D),
                            fontSize: 14,
                            fontFamily: 'Sora',
                            fontWeight: FontWeight.w400,
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
            SizedBox(height: 24),
            Text(
              "Enter Amount",
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 12,
                fontFamily: 'Sora',
                fontWeight: FontWeight.w400,
              ),
            ),
            SizedBox(height: 12),
            Container(
              width: 196,
              margin: EdgeInsets.only(
                left: 80,
                right: 82,
              ),
              child: TextFormField(
                focusNode: FocusNode(),
                autofocus: true,
                controller: priceController,
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 36,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w400,
                ),
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                  hintText: "\$00.00",
                  hintStyle: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 36,
                    fontFamily: 'Sora',
                    fontWeight: FontWeight.w400,
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0XFFFF4D4D),
                    ),
                  ),
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0XFFFF4D4D),
                    ),
                  ),
                  disabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0XFFFF4D4D),
                    ),
                  ),
                  border: UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0XFFFF4D4D),
                    ),
                  ),
                  isDense: true,
                  contentPadding: EdgeInsets.symmetric(horizontal: 26),
                ),
              ),
            ),
            SizedBox(height: 94),
            Container(
              width: double.maxFinite,
              padding: EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 40,
              ),
              decoration: BoxDecoration(
                color: Color(0XFFFFFFFF),
                boxShadow: [
                  BoxShadow(
                    color: Color(0X14000000),
                    spreadRadius: 2,
                    blurRadius: 2,
                    offset: Offset(
                      0,
                      -6,
                    ),
                  )
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 2),
                  Container(
                    width: double.maxFinite,
                    margin: EdgeInsets.symmetric(horizontal: 38),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Text(
                          "1",
                          style: TextStyle(
                            color: Color(0XFF191919),
                            fontSize: 21,
                            fontFamily: 'Sora',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          "2",
                          style: TextStyle(
                            color: Color(0XFF191919),
                            fontSize: 21,
                            fontFamily: 'Sora',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          "3",
                          style: TextStyle(
                            color: Color(0XFF191919),
                            fontSize: 21,
                            fontFamily: 'Sora',
                            fontWeight: FontWeight.w600,
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 38),
                  Container(
                    width: double.maxFinite,
                    margin: EdgeInsets.symmetric(horizontal: 36),
                    child: _buildNumberRow(
                      context,
                      number1: "4",
                      number2: "5",
                      number3: "6",
                    ),
                  ),
                  SizedBox(height: 38),
                  Container(
                    width: double.maxFinite,
                    margin: EdgeInsets.symmetric(horizontal: 36),
                    child: _buildNumberRow(
                      context,
                      number1: "7",
                      number2: "8",
                      number3: "9",
                    ),
                  ),
                  SizedBox(height: 38),
                  Container(
                    width: double.maxFinite,
                    margin: EdgeInsets.only(
                      left: 38,
                      right: 32,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(top: 6),
                          child: Text(
                            ".",
                            style: TextStyle(
                              color: Color(0XFF191919),
                              fontSize: 21,
                              fontFamily: 'Sora',
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        Text(
                          "0",
                          style: TextStyle(
                            color: Color(0XFF191919),
                            fontSize: 21,
                            fontFamily: 'Sora',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Padding(
                          child: SizedBox(
                            height: 24,
                            width: 24,
                            child: SvgPicture.asset(
                              "assets/images/img_delete_back_2_line.svg",
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 38),
                  Container(
                    width: double.maxFinite,
                    height: 44,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0XFFFF4D4D),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                            4,
                          ),
                        ),
                        visualDensity: const VisualDensity(
                          vertical: -4,
                          horizontal: -4,
                        ),
                        padding: EdgeInsets.symmetric(
                          horizontal: 30,
                          vertical: 12,
                        ),
                      ),
                      onPressed: () {},
                      child: Text(
                        "Done",
                        style: TextStyle(
                          color: Color(0XFFFFFFFF),
                          fontSize: 14,
                          fontFamily: 'Sora',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 58,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 66,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 8,
          top: 18,
          bottom: 18,
        ),
        child: Row(
          children: [
            SizedBox(
              height: 20,
              width: 20,
              child: SvgPicture.asset(
                "assets/images/img_arrow_left.svg",
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 2,
                bottom: 1,
              ),
              child: Text(
                "Back",
                style: TextStyle(
                  color: Color(0XFFFF4D4D),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildNumberRow(
    BuildContext context, {
    required String number1,
    required String number2,
    required String number3,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          number1,
          style: TextStyle(
            color: Color(0XFF191919),
            fontSize: 21,
            fontFamily: 'Sora',
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          number2,
          style: TextStyle(
            color: Color(0XFF191919),
            fontSize: 21,
            fontFamily: 'Sora',
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          number3,
          style: TextStyle(
            color: Color(0XFF191919),
            fontSize: 21,
            fontFamily: 'Sora',
            fontWeight: FontWeight.w600,
          ),
        )
      ],
    );
  }
}
