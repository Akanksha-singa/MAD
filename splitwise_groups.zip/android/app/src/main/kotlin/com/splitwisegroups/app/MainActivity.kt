package com.splitwisegroups.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
