import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SplitwiseGroupsScreen extends StatelessWidget {
  const SplitwiseGroupsScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        appBar: _buildAppBar(context),
        body: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    _buildFriendsGroupsSection(context),
                    SizedBox(height: 18),
                    SizedBox(
                      width: double.maxFinite,
                      child: Column(
                        children: [
                          _buildMovieNightColumn(context),
                          SizedBox(height: 12),
                          _buildTripToStack(context)
                        ],
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
        bottomNavigationBar: _buildBottomAppBar(context),
        floatingActionButton: _buildFloatingActionButton(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 64,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 57,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 13,
          top: 13,
          bottom: 13,
        ),
        child: Image.asset(
          "assets/images/img_userinfo.png",
          height: 38,
          width: 44,
        ),
      ),
      title: Padding(
        padding: EdgeInsets.only(left: 10),
        child: Column(
          children: [
            Text(
              "Split Wise",
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 13,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(height: 6),
            Padding(
              padding: EdgeInsets.only(right: 48),
              child: Text(
                "REX",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 8,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w800,
                ),
              ),
            )
          ],
        ),
      ),
      actions: [
        Padding(
          padding: EdgeInsets.only(
            top: 20,
            right: 23,
            bottom: 20,
          ),
          child: SizedBox(
            height: 24,
            width: 24,
            child: SvgPicture.asset(
              "assets/images/img_vector.svg",
            ),
          ),
        )
      ],
      flexibleSpace: Container(
        height: 64,
        width: 360,
        decoration: BoxDecoration(
          color: Color(0XFFFF4D4D),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBalanceSection(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.symmetric(
        horizontal: 4,
        vertical: 24,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          16,
        ),
        gradient: LinearGradient(
          begin: Alignment(0.91, -0.13),
          end: Alignment(0.5, 1),
          colors: [Color(0XFFFF4D4D), Color(0XFFE77676)],
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 62,
            width: 62,
            decoration: BoxDecoration(
              color: Color(0XFFFFFFFF),
              borderRadius: BorderRadius.circular(
                30,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "R",
                  style: TextStyle(
                    color: Color(0XFF4CBB9B),
                    fontSize: 36,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                )
              ],
            ),
          ),
          SizedBox(height: 10),
          Text(
            "Rex Kyojuro",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Lato',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 10),
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(
                8,
              ),
            ),
            width: double.maxFinite,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.max,
              children: [
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(top: 2),
                    child: Column(
                      children: [
                        Text(
                          "You are owed",
                          style: TextStyle(
                            color: Color(0XFFFFFFFF),
                            fontSize: 14,
                            fontFamily: 'Lato',
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        SizedBox(height: 10),
                        Container(
                          width: double.maxFinite,
                          margin: EdgeInsets.only(
                            left: 6,
                            right: 10,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Text(
                                  "₹",
                                  style: TextStyle(
                                    color: Color(0XFFFFFFFF),
                                    fontSize: 12,
                                    fontFamily: 'Lato',
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                              SizedBox(width: 4),
                              Text(
                                "1500",
                                style: TextStyle(
                                  color: Color(0XFFFFFFFF),
                                  fontSize: 24,
                                  fontFamily: 'Lato',
                                  fontWeight: FontWeight.w400,
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 8),
                  child: VerticalDivider(
                    width: 2,
                    thickness: 2,
                    color: Color(0XFF992E2E),
                  ),
                ),
                Expanded(
                  child: Container(
                    width: double.maxFinite,
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          "You owe",
                          style: TextStyle(
                            color: Color(0XFFFFFFFF),
                            fontSize: 14,
                            fontFamily: 'Lato',
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        SizedBox(height: 10),
                        SizedBox(
                          width: double.maxFinite,
                          child: _buildTotalBalanceRow(
                            context,
                            currencySymbol: "₹",
                            amount: "750",
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 8),
                  child: VerticalDivider(
                    width: 2,
                    thickness: 2,
                    color: Color(0XFF992E2E),
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "Total Balance",
                        style: TextStyle(
                          color: Color(0XFFFFFFFF),
                          fontSize: 14,
                          fontFamily: 'Lato',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 10),
                      Padding(
                        padding: EdgeInsets.only(right: 14),
                        child: _buildTotalBalanceRow(
                          context,
                          currencySymbol: "₹",
                          amount: "750",
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildFriendsGroupsSection(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          _buildBalanceSection(context),
          SizedBox(height: 48),
          Container(
            width: double.maxFinite,
            margin: EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  "FRIENDS",
                  style: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 14,
                    fontFamily: 'Lato',
                    fontWeight: FontWeight.w400,
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "GROUPS",
                        style: TextStyle(
                          color: Color(0XFFFFFFFF),
                          fontSize: 14,
                          fontFamily: 'Lato',
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      Container(
                        height: 2,
                        width: 40,
                        margin: EdgeInsets.only(right: 10),
                        decoration: BoxDecoration(
                          color: Color(0XFFFF4D4D),
                          borderRadius: BorderRadius.circular(
                            1,
                          ),
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileList(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (context, index) {
          return SizedBox(
            height: 16,
          );
        },
        itemCount: 3,
        itemBuilder: (context, index) {
          return UserprofilelistItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildMovieNightColumn(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [_buildUserProfileList(context)],
      ),
    );
  }

  /// Section Widget
  Widget _buildImageColumn(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        children: [
          Padding(
            child: SizedBox(
              height: 74,
              width: 100,
              child: SvgPicture.asset(
                "assets/images/img_ellipse_1.svg",
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildTripToRow(BuildContext context) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 10,
        ),
        decoration: BoxDecoration(
          color: Color(0XFFE77676),
          borderRadius: BorderRadius.circular(
            8,
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0X2D000000),
              spreadRadius: 2,
              blurRadius: 2,
              offset: Offset(
                0,
                0,
              ),
            )
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 50,
              width: 50,
              decoration: BoxDecoration(
                color: Color(0XFFE70202),
                borderRadius: BorderRadius.circular(
                  24,
                ),
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  IconButton(
                    onPressed: () {},
                    constraints: BoxConstraints(
                      minHeight: 46,
                      minWidth: 46,
                    ),
                    padding: EdgeInsets.all(0),
                    icon: Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: Color(0XFFE77676),
                        borderRadius: BorderRadius.circular(
                          22,
                        ),
                      ),
                      padding: EdgeInsets.all(8),
                      child: SvgPicture.asset(
                        "assets/images/img_group_4.svg",
                      ),
                    ),
                  )
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.only(left: 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Trip To Matheran",
                      style: TextStyle(
                        color: Color(0XFFFFFFFF),
                        fontSize: 12,
                        fontFamily: 'Lato',
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      "You owe Sushil Kumar",
                      style: TextStyle(
                        color: Color(0XFFFFFFFF),
                        fontSize: 10,
                        fontFamily: 'Lato',
                        fontWeight: FontWeight.w400,
                      ),
                    )
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 4,
                  bottom: 6,
                ),
                child: Text(
                  "₹",
                  style: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 12,
                    fontFamily: 'Lato',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 4,
                  bottom: 4,
                ),
                child: Text(
                  "500",
                  style: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 24,
                    fontFamily: 'Lato',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildTripToRowContainer(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [_buildTripToRow(context)],
      ),
    );
  }

  /// Section Widget
  Widget _buildTripToStack(BuildContext context) {
    return SizedBox(
      height: 144,
      width: double.maxFinite,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Container(
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [_buildImageColumn(context), SizedBox(height: 16)],
            ),
          ),
          _buildTripToRowContainer(context)
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomAppBar(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(
        20,
      ),
      child: BottomAppBar(
        shape: CircularNotchedRectangle(),
        color: Color(0XFFFF4D4D),
        child: SizedBox(
          height: 68,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              SizedBox(
                height: 12,
                width: 12,
                child: SvgPicture.asset(
                  "assets/images/img_vector_12x12.svg",
                ),
              ),
              SizedBox(
                height: 16,
                width: 12,
                child: SvgPicture.asset(
                  "assets/images/img_vector_16x12.svg",
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFloatingActionButton(BuildContext context) {
    return FloatingActionButton(
      backgroundColor: Color(0XFFFF4D4D),
      onPressed: () {},
      child: Container(
        alignment: Alignment.center,
        height: 50,
        width: 50,
        padding: EdgeInsets.all(
          10,
        ),
        decoration: BoxDecoration(
          color: Color(0XFFFF4D4D),
          borderRadius: BorderRadius.circular(
            24,
          ),
        ),
        child: SizedBox(
          height: 25.0,
          width: 25.0,
          child: SvgPicture.asset(
            "assets/images/img_group_9.svg",
            height: 25.0,
            width: 25.0,
          ),
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildTotalBalanceRow(
    BuildContext context, {
    required String currencySymbol,
    required String amount,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Align(
          alignment: Alignment.bottomCenter,
          child: Text(
            currencySymbol,
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Lato',
              fontWeight: FontWeight.w400,
            ),
          ),
        ),
        SizedBox(width: 4),
        Text(
          amount,
          style: TextStyle(
            color: Color(0XFFFFFFFF),
            fontSize: 24,
            fontFamily: 'Lato',
            fontWeight: FontWeight.w400,
          ),
        )
      ],
    );
  }
}

// ignore: must_be_immutable
class UserprofilelistItemWidget extends StatelessWidget {
  const UserprofilelistItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Color(0XFFE77676),
        borderRadius: BorderRadius.circular(
          8,
        ),
        boxShadow: [
          BoxShadow(
            color: Color(0X2D000000),
            spreadRadius: 2,
            blurRadius: 2,
            offset: Offset(
              0,
              0,
            ),
          )
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              color: Color(0XFFE70202),
              borderRadius: BorderRadius.circular(
                24,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                IconButton(
                  onPressed: () {},
                  constraints: BoxConstraints(
                    minHeight: 46,
                    minWidth: 46,
                  ),
                  padding: EdgeInsets.all(0),
                  icon: Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: Color(0XFFE77676),
                      borderRadius: BorderRadius.circular(
                        22,
                      ),
                    ),
                    padding: EdgeInsets.all(8),
                    child: SvgPicture.asset(
                      "assets/images/img_group_4.svg",
                    ),
                  ),
                )
              ],
            ),
          ),
          Expanded(
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.symmetric(horizontal: 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Trip To Lonavala",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 12,
                      fontFamily: 'Lato',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    "You owe Shubham",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 10,
                      fontFamily: 'Lato',
                      fontWeight: FontWeight.w400,
                    ),
                  )
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(
                left: 4,
                bottom: 6,
              ),
              child: Text(
                "₹",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 12,
                  fontFamily: 'Lato',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(
                left: 4,
                bottom: 4,
              ),
              child: Text(
                "500",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 24,
                  fontFamily: 'Lato',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
