import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class TransferScreen extends StatelessWidget {
  TransferScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Padding(
          padding: EdgeInsets.only(top: 24),
          child: SingleChildScrollView(
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.symmetric(horizontal: 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Transfer to",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 24,
                      fontFamily: 'Sora',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 42),
                  _buildSendToNewContact(context),
                  SizedBox(height: 16),
                  _buildDividerSection(context),
                  SizedBox(height: 16),
                  SizedBox(
                    width: 328,
                    child: TextFormField(
                      focusNode: FocusNode(),
                      autofocus: true,
                      controller: searchController,
                      style: TextStyle(
                        color: Color(0XFFFFFFFF),
                        fontSize: 14,
                        fontFamily: 'Sora',
                        fontWeight: FontWeight.w400,
                      ),
                      decoration: InputDecoration(
                        hintText: "Search contact",
                        hintStyle: TextStyle(
                          color: Color(0XFFFFFFFF),
                          fontSize: 14,
                          fontFamily: 'Sora',
                          fontWeight: FontWeight.w400,
                        ),
                        prefixIcon: Container(
                          margin: EdgeInsets.fromLTRB(12, 8, 8, 8),
                          child: SvgPicture.asset(
                            "assets/images/img_search.svg",
                            height: 20,
                            width: 20,
                          ),
                        ),
                        suffixIcon: Padding(
                          padding: EdgeInsets.only(
                            right: 15,
                          ),
                          child: IconButton(
                            onPressed: () {
                              searchController.clear();
                            },
                            icon: Icon(
                              Icons.clear,
                              color: Color(0xff757575),
                            ),
                          ),
                        ),
                      ),
                      onChanged: (value) {},
                    ),
                  ),
                  SizedBox(height: 16),
                  _buildFrequentContacts(context),
                  SizedBox(height: 24),
                  _buildAllContacts(context),
                  SizedBox(height: 16),
                  SizedBox(
                    width: double.maxFinite,
                    child: _buildAllContact(
                      context,
                      aneeshkpOne: "Aneesh KP",
                      mobileNo: "+91 8277608384",
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 58,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 73,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 15,
          top: 18,
          bottom: 18,
        ),
        child: Row(
          children: [
            SizedBox(
              height: 20,
              width: 20,
              child: SvgPicture.asset(
                "assets/images/img_arrow_left.svg",
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 2,
                bottom: 1,
              ),
              child: Text(
                "Back",
                style: TextStyle(
                  color: Color(0XFFFF4D4D),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildSendToNewContact(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          IconButton(
            onPressed: () {},
            constraints: BoxConstraints(
              minHeight: 48,
              minWidth: 48,
            ),
            padding: EdgeInsets.all(0),
            icon: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: Color(0XFFE77676),
                borderRadius: BorderRadius.circular(
                  24,
                ),
              ),
              padding: EdgeInsets.all(12),
              child: SvgPicture.asset(
                "assets/images/img_add_line.svg",
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 8),
            child: Text(
              "New contact",
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 12,
                fontFamily: 'Sora',
                fontWeight: FontWeight.w400,
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildDividerSection(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(top: 6),
              child: Divider(
                height: 1,
                thickness: 1,
                color: Color(0XFFFFFFFF),
              ),
            ),
          ),
          SizedBox(width: 16),
          Text(
            "or",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(top: 6),
              child: Divider(
                height: 1,
                thickness: 1,
                color: Color(0XFFFFFFFF),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildFrequentContacts(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Frequent contacts",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.maxFinite,
            child: _buildFrequentContact(
              context,
              akankshas: "Ajay N M",
              mobileNo: "+91 7892817647",
            ),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.maxFinite,
            child: Divider(
              height: 1,
              thickness: 1,
              color: Color(0XFFEDEEF6),
            ),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.maxFinite,
            child: _buildFrequentContact(
              context,
              akankshas: "Akanksha S",
              mobileNo: "+91 9036779915",
            ),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.maxFinite,
            child: Divider(
              height: 1,
              thickness: 1,
              color: Color(0XFFEDEEF6),
            ),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.maxFinite,
            child: _buildAllContact(
              context,
              aneeshkpOne: "Aneesh KP",
              mobileNo: "+91 8277608384",
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildAllContacts(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "All contacts",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.maxFinite,
            child: _buildFrequentContact(
              context,
              akankshas: "Ajay N M",
              mobileNo: "+91 7892817647",
            ),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.maxFinite,
            child: Divider(
              height: 1,
              thickness: 1,
              color: Color(0XFFEDEEF6),
            ),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.maxFinite,
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(
                    24,
                  ),
                  child: Image.asset(
                    "assets/images/img_profile_photo_48x48.png",
                    height: 48,
                    width: 48,
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: _buildContactInfo(
                    context,
                    userName: "Akanksha S",
                    mobileNumber: "+91 9036779915",
                  ),
                ),
                SizedBox(width: 8),
                Padding(
                  child: SizedBox(
                    height: 16,
                    width: 16,
                    child: SvgPicture.asset(
                      "assets/images/img_arrow_right.svg",
                    ),
                  ),
                )
              ],
            ),
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.maxFinite,
            child: Divider(
              height: 1,
              thickness: 1,
              color: Color(0XFFEDEEF6),
            ),
          )
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildFrequentContact(
    BuildContext context, {
    required String akankshas,
    required String mobileNo,
  }) {
    return Row(
      children: [
        ClipRRect(
          radius: BorderRadius.circular(
            24.0,
          ),
          child: Image.asset(
            "assets/images/img_profile_photo.png",
            height: 48,
            width: 48,
          ),
        ),
        SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                akankshas,
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 12,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 2),
              Text(
                mobileNo,
                style: TextStyle(
                  color: Color(0XFF78838D),
                  fontSize: 12,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w400,
                ),
              )
            ],
          ),
        ),
        SizedBox(width: 8),
        Padding(
          child: SizedBox(
            height: 16,
            width: 16,
            child: SvgPicture.asset(
              "assets/images/img_arrow_right.svg",
            ),
          ),
        )
      ],
    );
  }

  /// Common widget
  Widget _buildContactInfo(
    BuildContext context, {
    required String userName,
    required String mobileNumber,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          userName,
          style: TextStyle(
            color: Color(0XFFFFFFFF),
            fontSize: 12,
            fontFamily: 'Sora',
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2),
        Text(
          mobileNumber,
          style: TextStyle(
            color: Color(0XFF78838D),
            fontSize: 12,
            fontFamily: 'Sora',
            fontWeight: FontWeight.w400,
          ),
        )
      ],
    );
  }

  /// Common widget
  Widget _buildAllContact(
    BuildContext context, {
    required String aneeshkpOne,
    required String mobileNo,
  }) {
    return Row(
      children: [
        ClipRRect(
          radius: BorderRadius.circular(
            24.0,
          ),
          child: Image.asset(
            "assets/images/img_profile_photo.png",
            height: 48,
            width: 48,
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                aneeshkpOne,
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 12,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                mobileNo,
                style: TextStyle(
                  color: Color(0XFF78838D),
                  fontSize: 12,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w400,
                ),
              )
            ],
          ),
        ),
        SizedBox(width: 12),
        Padding(
          child: SizedBox(
            height: 16,
            width: 16,
            child: SvgPicture.asset(
              "assets/images/img_arrow_right.svg",
            ),
          ),
        )
      ],
    );
  }
}
