import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class RemaindersScreen extends StatelessWidget {
  const RemaindersScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        appBar: _buildAppbar(context),
        body: SizedBox(
          width: 360,
          child: Column(
            children: [
              SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildHomeIconColumn(context),
                      SizedBox(height: 296),
                      _buildComponentColumn(context)
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
        floatingActionButton: FloatingActionButton(
          backgroundColor: Color(0XFFFF4D4D),
          onPressed: () {},
          child: Container(
            alignment: Alignment.center,
            height: 44,
            width: 44,
            padding: EdgeInsets.all(
              10,
            ),
            decoration: BoxDecoration(
              color: Color(0XFFFF4D4D),
              borderRadius: BorderRadius.circular(
                22,
              ),
            ),
            child: SizedBox(
              height: 22.0,
              width: 22.0,
              child: SvgPicture.asset(
                "assets/images/img_group_1.svg",
                height: 22.0,
                width: 22.0,
              ),
            ),
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppbar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 64,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 67,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 13,
          top: 13,
          bottom: 13,
        ),
        child: Image.asset(
          "assets/images/img_group_500.png",
          height: 38,
          width: 54,
        ),
      ),
      title: Column(
        children: [
          Text(
            "Remainders",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 13,
              fontFamily: 'Inter',
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 9),
          Padding(
            padding: EdgeInsets.only(right: 60),
            child: Text(
              "REX",
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 8,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w800,
              ),
            ),
          )
        ],
      ),
      actions: [
        Padding(
          padding: EdgeInsets.only(
            top: 20,
            right: 23,
            bottom: 20,
          ),
          child: SizedBox(
            height: 24,
            width: 24,
            child: SvgPicture.asset(
              "assets/images/img_vector.svg",
            ),
          ),
        )
      ],
      flexibleSpace: Container(
        height: 64,
        width: 360,
        decoration: BoxDecoration(
          color: Color(0XFFFF4D4D),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileList(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (context, index) {
          return SizedBox(
            height: 16,
          );
        },
        itemCount: 4,
        itemBuilder: (context, index) {
          return UserprofilelistItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildHomeIconColumn(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [_buildUserProfileList(context)],
      ),
    );
  }

  /// Section Widget
  Widget _buildImageColumn(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.symmetric(horizontal: 2),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Padding(
            child: SizedBox(
              height: 74,
              width: 100,
              child: SvgPicture.asset(
                "assets/images/img_ellipse_1.svg",
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildComponentColumn(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [_buildImageColumn(context), SizedBox(height: 16)],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0XFFFF4D4D),
        borderRadius: BorderRadius.circular(
          20,
        ),
      ),
      child: BottomNavigationBar(
        backgroundColor: Colors.transparent,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        elevation: 0,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
            icon: SizedBox(
              height: 12,
              width: 12,
              child: SvgPicture.asset(
                "assets/images/img_vector_12x12.svg",
              ),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              height: 22,
              width: 22,
              child: SvgPicture.asset(
                "assets/images/img_budgeting_1.svg",
              ),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: FloatingActionButton(
              backgroundColor: Color(0XFFFF4D4D),
              onPressed: () {},
              child: Container(
                alignment: Alignment.center,
                height: 44,
                width: 44,
                padding: EdgeInsets.all(
                  10,
                ),
                decoration: BoxDecoration(
                  color: Color(0XFFFF4D4D),
                  borderRadius: BorderRadius.circular(
                    22,
                  ),
                ),
                child: SizedBox(
                  height: 22.0,
                  width: 22.0,
                  child: SvgPicture.asset(
                    "assets/images/img_group_1.svg",
                    height: 22.0,
                    width: 22.0,
                  ),
                ),
              ),
            ),
            label: '',
          )
        ],
      ),
    );
  }
}

// ignore: must_be_immutable
class UserprofilelistItemWidget extends StatelessWidget {
  const UserprofilelistItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return _buildUserProfile(context);
  }

  /// Section Widget
  Widget _buildUserProfile(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 6,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        color: Color(0XFFE77676),
        borderRadius: BorderRadius.circular(
          8,
        ),
        boxShadow: [
          BoxShadow(
            color: Color(0X2D000000),
            spreadRadius: 2,
            blurRadius: 2,
            offset: Offset(
              0,
              0,
            ),
          )
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              color: Color(0XFFE70202),
              borderRadius: BorderRadius.circular(
                24,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                IconButton(
                  onPressed: () {},
                  constraints: BoxConstraints(
                    minHeight: 46,
                    minWidth: 46,
                  ),
                  padding: EdgeInsets.all(0),
                  icon: Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      color: Color(0XFFE77676),
                      borderRadius: BorderRadius.circular(
                        22,
                      ),
                    ),
                    padding: EdgeInsets.all(10),
                    child: SvgPicture.asset(
                      "assets/images/img_home_3_fill.svg",
                    ),
                  ),
                )
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(left: 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Monthly  Rent",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 12,
                      fontFamily: 'Lato',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    "Due date: 13th June, 2024",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 10,
                      fontFamily: 'Lato',
                      fontWeight: FontWeight.w400,
                    ),
                  )
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(
                left: 4,
                bottom: 6,
              ),
              child: Text(
                "₹",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 12,
                  fontFamily: 'Lato',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(
                left: 4,
                bottom: 4,
              ),
              child: Text(
                "8000",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 24,
                  fontFamily: 'Lato',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
