import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class PasswordScreen extends StatelessWidget {
  PasswordScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 46,
          ),
          child: Column(
            children: [_buildMainContent(context), SizedBox(height: 4)],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 58,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 66,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 8,
          top: 18,
          bottom: 18,
        ),
        child: Row(
          children: [
            SizedBox(
              height: 20,
              width: 20,
              child: SvgPicture.asset(
                "assets/images/img_arrow_left.svg",
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 2,
                bottom: 1,
              ),
              child: Text(
                "Back",
                style: TextStyle(
                  color: Color(0XFFFF4D4D),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildPasswordInput(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Password",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 4),
          Container(
            width: 328,
            child: TextFormField(
              focusNode: FocusNode(),
              autofocus: true,
              controller: passwordController,
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 14,
                fontFamily: 'Sora',
                fontWeight: FontWeight.w400,
              ),
              textInputAction: TextInputAction.done,
              obscureText: true,
              decoration: InputDecoration(
                hintText: "Enter your password",
                hintStyle: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w400,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                disabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(
                    4,
                  ),
                  borderSide: BorderSide(
                    color: Color(0XFFFFFFFF),
                    width: 1,
                  ),
                ),
                suffixIcon: Container(
                  margin: EdgeInsets.fromLTRB(30, 12, 12, 12),
                  child: SvgPicture.asset(
                    "assets/images/img_eyeoffline.svg",
                    height: 20,
                    width: 20,
                  ),
                ),
                suffixIconConstraints: BoxConstraints(
                  maxHeight: 44,
                ),
                isDense: true,
                contentPadding: EdgeInsets.only(
                  left: 12,
                  top: 12,
                  bottom: 12,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildTopSection(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Enter your password",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 21,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 20),
          _buildPasswordInput(context),
          SizedBox(height: 20),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              "Forgot password?",
              style: TextStyle(
                color: Color(0XFFFF4D4D),
                fontSize: 14,
                fontFamily: 'Sora',
                fontWeight: FontWeight.w600,
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildLoginButton(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      height: 44,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Color(0XFFFF4D4D),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
              4,
            ),
          ),
          visualDensity: const VisualDensity(
            vertical: -4,
            horizontal: -4,
          ),
          padding: EdgeInsets.symmetric(
            horizontal: 30,
            vertical: 12,
          ),
        ),
        onPressed: () {},
        child: Text(
          "Login",
          style: TextStyle(
            color: Color(0XFFFFFFFF),
            fontSize: 14,
            fontFamily: 'Sora',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildMainContent(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.only(right: 14),
        child: Column(
          children: [
            Padding(
              child: SizedBox(
                height: 178,
                width: 142,
                child: SvgPicture.asset(
                  "assets/images/img_group_7.svg",
                ),
              ),
            ),
            SizedBox(height: 8),
            SizedBox(
              height: 8,
              width: 156,
              child: SvgPicture.asset(
                "assets/images/img_freepik_path.svg",
              ),
            ),
            Spacer(),
            _buildTopSection(context),
            SizedBox(height: 96),
            _buildLoginButton(context)
          ],
        ),
      ),
    );
  }
}
