import 'package:flutter/material.dart';
import 'package:country_pickers/country.dart';
import 'package:country_pickers/country_pickers.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'widgets.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key})
      : super(
          key: key,
        );

  Country selectedCountry = CountryPickerUtils.getCountryByPhoneCode('962');

  TextEditingController phoneNumberController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 10,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 118),
                child: Text(
                  "PWM",
                  style: TextStyle(
                    color: Color(0XFFFF4D4D),
                    fontSize: 20,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              SizedBox(height: 40),
              Padding(
                padding: EdgeInsets.only(left: 52),
                child: SizedBox(
                  height: 190,
                  width: 186,
                  child: SvgPicture.asset(
                    "assets/images/img_group_10.svg",
                  ),
                ),
              ),
              SizedBox(height: 68),
              SizedBox(
                width: 164,
                child: Text(
                  "Enter your mobile number",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 21,
                    fontFamily: 'Sora',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              SizedBox(height: 8),
              _buildInputSection(context),
              SizedBox(height: 28),
              Padding(
                padding: EdgeInsets.only(left: 2),
                child: Text(
                  "Create Account",
                  style: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 16,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              SizedBox(height: 30),
              SizedBox(
                width: double.maxFinite,
                height: 44,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0XFFFF4D4D),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        4,
                      ),
                    ),
                    visualDensity: const VisualDensity(
                      vertical: -4,
                      horizontal: -4,
                    ),
                    padding: EdgeInsets.symmetric(
                      horizontal: 30,
                      vertical: 12,
                    ),
                  ),
                  onPressed: () {},
                  child: Text(
                    "Continue",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 14,
                      fontFamily: 'Sora',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20),
              _buildDividerSection(context),
              SizedBox(height: 8)
            ],
          ),
        ),
        bottomNavigationBar: _buildSocialLogin(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 56,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 66,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 8,
          top: 18,
          bottom: 18,
        ),
        child: Row(
          children: [
            SizedBox(
              height: 20,
              width: 20,
              child: SvgPicture.asset(
                "assets/images/img_arrow_left.svg",
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 2,
                bottom: 1,
              ),
              child: Text(
                "Back",
                style: TextStyle(
                  color: Color(0XFFFF4D4D),
                  fontSize: 14,
                  fontFamily: 'Sora',
                  fontWeight: FontWeight.w600,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildInputSection(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Mobile number",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 4),
          SizedBox(
            width: double.maxFinite,
            child: CustomPhoneNumber(
              country: selectedCountry,
              controller: phoneNumberController,
              onTap: (Country value) {
                selectedCountry = value;
              },
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildDividerSection(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(top: 6),
              child: Divider(
                height: 1,
                thickness: 1,
                color: Color(0XFFFFFFFF),
              ),
            ),
          ),
          SizedBox(width: 16),
          Text(
            "or continue using",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Sora',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(top: 6),
              child: Divider(
                height: 1,
                thickness: 1,
                color: Color(0XFFFFFFFF),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSocialLogin(BuildContext context) {
    return Container(
      height: 44,
      margin: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: 30,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Spacer(
            flex: 41,
          ),
          Container(
            height: 24,
            width: 24,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(
                4,
              ),
              border: Border.all(
                color: Color(0XFFEDEEF6),
                width: 1,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                IconButton(
                  onPressed: () {},
                  constraints: BoxConstraints(
                    minHeight: 24,
                    minWidth: 24,
                  ),
                  padding: EdgeInsets.all(0),
                  icon: Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: Color(0XFF1977F3),
                      borderRadius: BorderRadius.circular(
                        12,
                      ),
                    ),
                    child: SvgPicture.asset(
                      "assets/images/img_facebook_f_logo_2019.svg",
                    ),
                  ),
                )
              ],
            ),
          ),
          Spacer(
            flex: 58,
          ),
          Container(
            height: 44,
            width: 98,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(
                4,
              ),
              border: Border.all(
                color: Color(0XFFEDEEF6),
                width: 1,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Padding(
                  child: SizedBox(
                    height: 24,
                    width: 22,
                    child: SvgPicture.asset(
                      "assets/images/img_google.svg",
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            height: 44,
            width: 98,
            margin: EdgeInsets.only(left: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(
                4,
              ),
              border: Border.all(
                color: Color(0XFFEDEEF6),
                width: 1,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Padding(
                  child: SizedBox(
                    height: 24,
                    width: 18,
                    child: SvgPicture.asset(
                      "assets/images/img_path1504.svg",
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
