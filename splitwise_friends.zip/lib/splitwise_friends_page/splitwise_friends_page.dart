import 'package:flutter/material.dart'; // ignore_for_file: must_be_immutable

class SplitwiseFriendsPage extends StatefulWidget {
  const SplitwiseFriendsPage({Key? key})
      : super(
          key: key,
        );

  @override
  SplitwiseFriendsPageState createState() => SplitwiseFriendsPageState();
}

class SplitwiseFriendsPageState extends State<SplitwiseFriendsPage>
    with AutomaticKeepAliveClientMixin<SplitwiseFriendsPage> {
  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(
          children: [
            SizedBox(height: 18),
            SizedBox(
              width: double.maxFinite,
              child: ListView.separated(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                separatorBuilder: (context, index) {
                  return SizedBox(
                    height: 14,
                  );
                },
                itemCount: 5,
                itemBuilder: (context, index) {
                  return UserprofileItemWidget();
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class UserprofileItemWidget extends StatelessWidget {
  const UserprofileItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return _buildUserProfileAjay(context);
  }

  /// Section Widget
  Widget _buildUserProfileAjay(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 4,
        vertical: 2,
      ),
      decoration: BoxDecoration(
        color: Color(0XFFE77676),
        borderRadius: BorderRadius.circular(
          8,
        ),
        boxShadow: [
          BoxShadow(
            color: Color(0X2D000000),
            spreadRadius: 2,
            blurRadius: 2,
            offset: Offset(
              0,
              0,
            ),
          )
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(
                32,
              ),
              child: Image.asset(
                "assets/images/img_profile_photo.png",
                height: 64,
                width: 64,
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(left: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Ajay N M ",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 12,
                      fontFamily: 'Lato',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    "You owe",
                    style: TextStyle(
                      color: Color(0XFFFFFFFF),
                      fontSize: 10,
                      fontFamily: 'Lato',
                      fontWeight: FontWeight.w400,
                    ),
                  )
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(
                left: 4,
                bottom: 14,
              ),
              child: Text(
                "₹",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 12,
                  fontFamily: 'Lato',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(
                left: 6,
                bottom: 12,
              ),
              child: Text(
                "500",
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 24,
                  fontFamily: 'Lato',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
