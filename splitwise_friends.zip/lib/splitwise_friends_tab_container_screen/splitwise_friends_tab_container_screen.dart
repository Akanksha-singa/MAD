import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SplitwiseFriendsTabContainerScreen extends StatefulWidget {
  const SplitwiseFriendsTabContainerScreen({Key? key})
      : super(
          key: key,
        );

  @override
  SplitwiseFriendsTabContainerScreenState createState() =>
      SplitwiseFriendsTabContainerScreenState();
}
// ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class SplitwiseFriendsTabContainerScreenState
    extends State<SplitwiseFriendsTabContainerScreen>
    with TickerProviderStateMixin {
  late TabController tabviewController;

  @override
  void initState() {
    super.initState();
    tabviewController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFF000000),
        appBar: _buildAppBar(context),
        body: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height: 22),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    _buildUserInfoSection(context),
                    _buildTabBarView(context)
                  ],
                ),
              ),
            )
          ],
        ),
        bottomNavigationBar: _buildBottomAppBar(context),
        floatingActionButton: _buildFloatingActionButton(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      elevation: 0,
      toolbarHeight: 64,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      leadingWidth: 67,
      leading: Padding(
        padding: EdgeInsets.only(
          left: 13,
          top: 13,
          bottom: 13,
        ),
        child: Image.asset(
          "assets/images/img_group_499.png",
          height: 38,
          width: 54,
        ),
      ),
      title: Column(
        children: [
          Text(
            "Split Wise",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 13,
              fontFamily: 'Inter',
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 6),
          Padding(
            padding: EdgeInsets.only(right: 48),
            child: Text(
              "REX",
              style: TextStyle(
                color: Color(0XFFFFFFFF),
                fontSize: 8,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w800,
              ),
            ),
          )
        ],
      ),
      actions: [
        Padding(
          padding: EdgeInsets.only(
            top: 20,
            right: 23,
            bottom: 20,
          ),
          child: SizedBox(
            height: 24,
            width: 24,
            child: SvgPicture.asset(
              "assets/images/img_vector.svg",
            ),
          ),
        )
      ],
      flexibleSpace: Container(
        height: 64,
        width: 360,
        decoration: BoxDecoration(
          color: Color(0XFFFF4D4D),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBalanceSection(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.symmetric(vertical: 24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          16,
        ),
        gradient: LinearGradient(
          begin: Alignment(0.91, -0.13),
          end: Alignment(0.5, 1),
          colors: [Color(0XFFFF4D4D), Color(0XFFE77676)],
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 62,
            width: 62,
            decoration: BoxDecoration(
              color: Color(0XFFFFFFFF),
              borderRadius: BorderRadius.circular(
                30,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "R",
                  style: TextStyle(
                    color: Color(0XFF4CBB9B),
                    fontSize: 36,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(height: 2)
              ],
            ),
          ),
          SizedBox(height: 12),
          Text(
            "Rex Kyojuro",
            style: TextStyle(
              color: Color(0XFFFFFFFF),
              fontSize: 12,
              fontFamily: 'Lato',
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(height: 12),
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(
                8,
              ),
            ),
            width: double.maxFinite,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(top: 2),
                    child: Column(
                      children: [
                        Text(
                          "You are owed",
                          style: TextStyle(
                            color: Color(0XFFFFFFFF),
                            fontSize: 14,
                            fontFamily: 'Lato',
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        SizedBox(height: 10),
                        Container(
                          width: double.maxFinite,
                          margin: EdgeInsets.symmetric(horizontal: 8),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Text(
                                  "₹",
                                  style: TextStyle(
                                    color: Color(0XFFFFFFFF),
                                    fontSize: 12,
                                    fontFamily: 'Lato',
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                              SizedBox(width: 6),
                              Text(
                                "1500",
                                style: TextStyle(
                                  color: Color(0XFFFFFFFF),
                                  fontSize: 24,
                                  fontFamily: 'Lato',
                                  fontWeight: FontWeight.w400,
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 10),
                  child: VerticalDivider(
                    width: 2,
                    thickness: 2,
                    color: Color(0XFF992E2E),
                  ),
                ),
                Expanded(
                  child: _buildTotalBalanceSection(
                    context,
                    totalBalanceText: "You owe",
                    currencySymbolText: "₹",
                    amountText: "750",
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 10),
                  child: VerticalDivider(
                    width: 2,
                    thickness: 2,
                    color: Color(0XFF992E2E),
                  ),
                ),
                Expanded(
                  child: _buildTotalBalanceSection(
                    context,
                    totalBalanceText: "Total Balance",
                    currencySymbolText: "₹",
                    amountText: "750",
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildUserInfoSection(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.only(
        left: 18,
        right: 22,
      ),
      child: Column(
        children: [
          _buildBalanceSection(context),
          SizedBox(height: 48),
          Container(
            height: 18,
            margin: EdgeInsets.symmetric(horizontal: 48),
            width: double.maxFinite,
            child: TabBar(
              controller: tabviewController,
              labelPadding: EdgeInsets.zero,
              tabs: [
                Tab(
                  child: Text(
                    "FRIENDS",
                  ),
                ),
                Tab(
                  child: Text(
                    "GROUPS",
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildTabBarView(BuildContext context) {
    return SizedBox(
      height: 348,
      width: double.maxFinite,
      child: TabBarView(
        controller: tabviewController,
        children: [SplitwiseFriendsPage(), SplitwiseFriendsPage()],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomAppBar(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(
        20,
      ),
      child: BottomAppBar(
        shape: CircularNotchedRectangle(),
        color: Color(0XFFFF4D4D),
        child: SizedBox(
          height: 68,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              SizedBox(
                height: 12,
                width: 12,
                child: SvgPicture.asset(
                  "assets/images/img_vector_12x12.svg",
                ),
              ),
              SizedBox(
                height: 16,
                width: 12,
                child: SvgPicture.asset(
                  "assets/images/img_vector_16x12.svg",
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFloatingActionButton(BuildContext context) {
    return FloatingActionButton(
      backgroundColor: Color(0XFFFF4D4D),
      onPressed: () {},
      child: Container(
        alignment: Alignment.center,
        height: 50,
        width: 50,
        padding: EdgeInsets.all(
          10,
        ),
        decoration: BoxDecoration(
          color: Color(0XFFFF4D4D),
          borderRadius: BorderRadius.circular(
            24,
          ),
        ),
        child: SizedBox(
          height: 25.0,
          width: 25.0,
          child: SvgPicture.asset(
            "assets/images/img_group_9.svg",
            height: 25.0,
            width: 25.0,
          ),
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildTotalBalanceSection(
    BuildContext context, {
    required String totalBalanceText,
    required String currencySymbolText,
    required String amountText,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          totalBalanceText,
          style: TextStyle(
            color: Color(0XFFFFFFFF),
            fontSize: 14,
            fontFamily: 'Lato',
            fontWeight: FontWeight.w700,
          ),
        ),
        SizedBox(height: 10),
        Padding(
          padding: EdgeInsets.only(right: 14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Align(
                alignment: Alignment.bottomCenter,
                child: Text(
                  currencySymbolText,
                  style: TextStyle(
                    color: Color(0XFFFFFFFF),
                    fontSize: 12,
                    fontFamily: 'Lato',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
              SizedBox(width: 6),
              Text(
                amountText,
                style: TextStyle(
                  color: Color(0XFFFFFFFF),
                  fontSize: 24,
                  fontFamily: 'Lato',
                  fontWeight: FontWeight.w400,
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}
