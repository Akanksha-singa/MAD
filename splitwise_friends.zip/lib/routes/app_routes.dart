import 'package:flutter/material.dart';
import '../splitwise_friends_page/splitwise_friends_page.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class AppRoutes {
  static const String splitwiseFriendsPage = '/splitwise_friends_page';

  static const String splitwiseFriendsTabContainerScreen =
      '/splitwise_friends_tab_container_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> routes = {
    splitwiseFriendsTabContainerScreen: (context) =>
        SplitwiseFriendsTabContainerScreen(),
    initialRoute: (context) => SplitwiseFriendsTabContainerScreen()
  };
}
